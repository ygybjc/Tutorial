# finalspeed
finalspeed
服务器TCP双边加速软件可达到90%的物理带宽利用率


安装脚本：

rm -f install_fs.sh
wget https://raw.githubusercontent.com/johnfreeman9/finalspeed/master/install_fs.sh
chmod +x install_fs.sh
./install_fs.sh 2>&1 | tee install.log
